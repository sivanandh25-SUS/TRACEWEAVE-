"""TRACEWEAVE FINANCE - investigation dashboard (Streamlit).

Run:  streamlit run dashboard.py
Every number, table and classification on screen is computed by app/engine.py.
"""
import csv
import io
import json
import os
import tempfile

import pandas as pd
import plotly.express as px
import streamlit as st

from app.engine import load_dataset, analyse, DECISION_VERIFIED, DECISION_REVIEW, DECISION_REJECT

ROOT = os.path.dirname(os.path.abspath(__file__))
DATASETS = {
    "Investigation evidence (E04, E18, E19)": os.path.join(ROOT, "data", "evidence_excerpt.json"),
    "Scenario A - Legitimate change (synthetic)": os.path.join(ROOT, "data", "synthetic", "scenario_A_legitimate.json"),
    "Scenario C - Unknown credential (synthetic)": os.path.join(ROOT, "data", "synthetic", "scenario_C_unauthorised.json"),
}
COLOURS = {DECISION_VERIFIED: "#2F9E7A", DECISION_REVIEW: "#B7791F", DECISION_REJECT: "#C8463D"}

st.set_page_config(page_title="TRACEWEAVE FINANCE", layout="wide")
st.markdown("""
<style>
html, body, [class*="css"] { font-family: 'Calibri', 'Carlito', sans-serif; }
h1, h2, h3 { color: #10243A; }
.badge { display:inline-block; padding:4px 12px; border-radius:12px; color:white; font-weight:600; }
</style>
""", unsafe_allow_html=True)

st.sidebar.title("TRACEWEAVE FINANCE")
st.sidebar.caption("CodeNexus · Financial Security · Approach: DEFENSE")
choice = st.sidebar.selectbox("Dataset", list(DATASETS.keys()))
uploaded = st.sidebar.file_uploader("Or upload a dataset (JSON)", type=["json"])

try:
    if uploaded is not None:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as tmp:
            tmp.write(uploaded.getvalue())
            path = tmp.name
        dataset = load_dataset(path)
        dataset["_source_file"] = uploaded.name
    else:
        dataset = load_dataset(DATASETS[choice])
except (ValueError, json.JSONDecodeError) as e:
    st.error(f"Dataset rejected: {e}")
    st.stop()

results = analyse(dataset)
df = pd.DataFrame(results)

if dataset.get("synthetic"):
    st.warning("SYNTHETIC DEMONSTRATION DATA. Not part of the original investigation evidence.")
st.caption(f"Source: {os.path.basename(str(dataset['_source_file']))} · SHA-256 {dataset['_sha256'][:16]}…")

tabs = st.tabs(["Overview", "Vendor changes", "API security", "Approvals",
                "Trust decision", "Timeline", "Report"])

with tabs[0]:
    st.header("Security overview")
    counts = {d: int((df["decision"] == d).sum()) if not df.empty else 0
              for d in (DECISION_VERIFIED, DECISION_REVIEW, DECISION_REJECT)}
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Evidence records", len(dataset["vendor_changes"]) + len(dataset["api_logs"]))
    c2.metric("Sensitive changes", len(results))
    c3.metric("Manual review", counts[DECISION_REVIEW])
    c4.metric("High-risk alerts", counts[DECISION_REJECT])
    if not df.empty:
        fig = px.bar(df.groupby("decision").size().reset_index(name="changes"),
                     x="decision", y="changes", color="decision",
                     color_discrete_map=COLOURS, title="Decision distribution")
        fig.update_layout(showlegend=False, height=340)
        st.plotly_chart(fig, use_container_width=True)
    st.info("No payment is blocked automatically. Decisions recommend verification or a simulated hold.")

with tabs[1]:
    st.header("Vendor change monitoring")
    if df.empty:
        st.write("No sensitive changes in this dataset.")
    else:
        st.dataframe(df[["record_id", "vendor_id", "vendor_name", "timestamp", "old_masked",
                         "new_masked", "approval_status", "decision"]], use_container_width=True)

with tabs[2]:
    st.header("API identity and permission analysis")
    for entry in dataset["register"]:
        st.subheader(entry["key_id"])
        st.write(f"Owner: {entry.get('owner', '-')} · Software: {entry.get('software', '-')}")
        st.write(f"Scopes: {', '.join(entry.get('scopes', [])) or 'none'}")
        st.write(f"IP restriction: {', '.join(entry.get('ip_restrictions', [])) or 'none recorded'}")
        st.write(f"Expiry: {entry.get('expires') or 'none recorded'}")
    unknown = sorted({c['changed_by'] for c in dataset['vendor_changes']} - {e['key_id'] for e in dataset['register']})
    if unknown:
        st.error(f"Unregistered credentials used: {', '.join(unknown)}")

with tabs[3]:
    st.header("Approval verification")
    if df.empty:
        st.write("No sensitive changes to verify.")
    else:
        st.dataframe(df[["record_id", "vendor_id", "approval_status", "decision"]], use_container_width=True)
        st.caption("Blank references are reported as missing. A non-empty reference is only valid when it matches vendor, bank details and timing, with an independent approver.")

with tabs[4]:
    st.header("Trust decision centre")
    if df.empty:
        st.write("Nothing to decide.")
    for r in results:
        st.subheader(f"{r['record_id']} · {r['vendor_id']}")
        st.markdown(f"<span class='badge' style='background:{COLOURS[r['decision']]}'>{r['decision']}</span>",
                    unsafe_allow_html=True)
        st.write(r["explanation"])
        st.markdown("**Reasons**")
        for reason in r["reasons"]:
            st.write(f"- {reason}")
        st.markdown("**Evidence references**")
        for ev in r["evidence"]:
            st.write(f"- {ev}")
        st.markdown(f"**Recommended action:** {r['recommended_action']}")

with tabs[5]:
    st.header("Investigation timeline")
    if df.empty:
        st.write("No events.")
    else:
        for r in sorted(results, key=lambda x: x["timestamp"]):
            st.write(f"**{r['timestamp']}** · request `{r['request_id']}` · key `{r['changed_by']}` · "
                     f"IP `{r['source_ip']}` · {'matched' if r['correlated'] else 'NOT matched'} to API log")

with tabs[6]:
    st.header("Investigation report")
    if df.empty:
        st.write("Nothing to report.")
    else:
        flat = df.copy()
        flat["reasons"] = flat["reasons"].apply(lambda x: " | ".join(x))
        flat["evidence"] = flat["evidence"].apply(lambda x: " | ".join(x))
        st.dataframe(flat[["record_id", "vendor_id", "decision", "explanation"]], use_container_width=True)
        buf = io.StringIO()
        flat.to_csv(buf, index=False)
        st.download_button("Download CSV report", buf.getvalue(), file_name="traceweave_report.csv", mime="text/csv")
