"""Command-line runner: analyse a dataset and write a CSV report."""
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.engine import load_dataset, analyse  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASETS = [
    os.path.join(ROOT, "data", "evidence_excerpt.json"),
    os.path.join(ROOT, "data", "synthetic", "scenario_A_legitimate.json"),
    os.path.join(ROOT, "data", "synthetic", "scenario_C_unauthorised.json"),
]


def main():
    out_dir = os.path.join(ROOT, "reports")
    os.makedirs(out_dir, exist_ok=True)
    for path in DATASETS:
        data = load_dataset(path)
        results = analyse(data)
        print(f"\n== {data.get('name', path)} (SHA-256 {data['_sha256'][:16]}...)")
        for r in results:
            print(f"  {r['record_id']}  {r['vendor_id']}  -> {r['decision']}")
            print(f"     {r['explanation']}")
        name = os.path.splitext(os.path.basename(path))[0] + "_report.csv"
        with open(os.path.join(out_dir, name), "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=[k for k in results[0].keys() if k not in ("reasons", "evidence")] + ["reasons", "evidence"]) if results else None
            if writer:
                writer.writeheader()
                for r in results:
                    row = dict(r)
                    row["reasons"] = " | ".join(r["reasons"])
                    row["evidence"] = " | ".join(r["evidence"])
                    writer.writerow(row)
    print("\nReports written to", out_dir)


if __name__ == "__main__":
    main()
