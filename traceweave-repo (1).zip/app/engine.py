"""TRACEWEAVE FINANCE - decision engine.

Standard library only, so it can be tested without installing anything.
Three modules feed one trust decision:
  1. Vendor change guardian      (is this a sensitive change?)
  2. API identity & permissions  (is the key known and is the operation in scope?)
  3. Approval verification       (is there a valid, independent approval?)
"""
import hashlib
import json
from datetime import datetime

SENSITIVE_FIELDS = {"bank_account", "beneficiary", "ifsc"}
REQUIRED_SCOPE = "vendor.bank.write"
DECISION_VERIFIED = "VERIFIED"
DECISION_REVIEW = "MANUAL REVIEW"
DECISION_REJECT = "REJECT / HIGH-RISK ALERT"
REJECT_ACTION = "Block the change and escalate to security."


def mask_account(value):
    """Show only the last four characters of an account number."""
    if not value:
        return "-"
    s = str(value).replace("*", "")
    return "****" + s[-4:]


def parse_ts(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def load_dataset(path):
    """Load a dataset JSON file. Malformed input raises ValueError; nothing is silently skipped."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    for key in ("register", "vendor_changes", "api_logs", "approvals"):
        if key not in data or not isinstance(data[key], list):
            raise ValueError(f"Dataset is missing a valid '{key}' list")
    for change in data["vendor_changes"]:
        for field in ("record_id", "vendor_id", "timestamp", "changed_field", "changed_by", "request_id"):
            if not change.get(field):
                raise ValueError(f"Change {change.get('record_id', '?')} is missing '{field}'")
    data["_sha256"] = file_sha256(path)
    data["_source_file"] = path
    return data


# ---------- Module 2: API identity and permissions ----------
def check_api_identity(key_id, register):
    entry = next((r for r in register if r["key_id"] == key_id), None)
    if entry is None:
        return {"status": "unknown", "entry": None,
                "findings": [f"Key {key_id} is not in the integration register"],
                "scope_failed": True}
    scopes = entry.get("scopes", [])
    findings = []
    scope_failed = REQUIRED_SCOPE not in scopes and "ALL" not in scopes
    if scope_failed:
        findings.append(f"Key lacks required scope '{REQUIRED_SCOPE}' for a sensitive endpoint")
    if "ALL" in scopes:
        findings.append("Broad permissions: read/write across all modules")
    if not entry.get("ip_restrictions"):
        findings.append("No IP restriction recorded for this key")
    if not entry.get("expires"):
        findings.append("No credential expiry or lifetime recorded")
    return {"status": "registered", "entry": entry, "findings": findings, "scope_failed": scope_failed}


# ---------- Module 3: independent approval verification ----------
def verify_approval(change, approvals):
    ref = (change.get("approval_reference") or "").strip()
    if not ref:
        return {"status": "missing", "findings": ["Approval reference is blank in the change record"]}
    rec = next((a for a in approvals if a["approval_id"] == ref), None)
    if rec is None:
        return {"status": "not_found", "findings": [f"Approval {ref} not found in approval registry"]}
    findings = []
    if rec["vendor_id"] != change["vendor_id"]:
        findings.append("Approval is for a different vendor")
    if rec["new_bank_account"] != change["new_value"]:
        findings.append("Approved bank details do not match the change")
    if parse_ts(rec["approved_at"]) > parse_ts(change["timestamp"]):
        findings.append("Approval was recorded after the change")
    if rec["approver"] == change.get("changed_by"):
        findings.append("Approver is the same identity that made the change")
    if findings:
        return {"status": "mismatch", "findings": findings}
    return {"status": "valid", "findings": ["Approval matches vendor, bank details and timing, and is independent"]}


# ---------- Correlation ----------
def correlate(change, api_logs):
    """Match the change to an API log by request ID, key, IP and timestamp."""
    for log in api_logs:
        if log["request_id"] == change["request_id"]:
            checks = {
                "request_id": True,
                "key_id": log["key_id"] == change["changed_by"],
                "source_ip": log["caller_ip"] == change["source_ip"],
                "timestamp": log["timestamp"] == change["timestamp"],
            }
            return {"matched": all(checks.values()), "log": log, "checks": checks}
    return {"matched": False, "log": None, "checks": {}}


# ---------- Trust decision ----------
def decide(change, identity, approval, correlation):
    """Combine the three modules. Rules are explicit so every result can be explained."""
    evidence = [f"Change record: {change['record_id']}"]
    if correlation["matched"]:
        evidence.append(f"API log: {correlation['log']['log_id']} (same request ID, key, IP and timestamp)")
    gaps = []
    if not correlation["matched"]:
        gaps.append("No API log matches this change's request ID, key, IP and timestamp")

    # REJECT rules
    if identity["status"] == "unknown" or identity["scope_failed"]:
        return DECISION_REJECT, identity["findings"] + gaps, evidence, REJECT_ACTION
    if approval["status"] in ("mismatch", "not_found"):
        return DECISION_REJECT, approval["findings"] + gaps, evidence, REJECT_ACTION

    # MANUAL REVIEW rules
    review = list(gaps)
    if approval["status"] == "missing":
        review += approval["findings"]
    review += identity["findings"]
    if review:
        return DECISION_REVIEW, review, evidence, (
            "Hold the bank-detail change for independent verification before any payment. "
            "Obtain the approval record and confirm the new details with the vendor through a known contact.")

    # VERIFIED
    return DECISION_VERIFIED, approval["findings"] + ["Identity and permissions within policy"], evidence, (
        "Allow the change and keep the record on file for audit.")


def analyse(dataset):
    """Run every sensitive change through all modules and return one result per change."""
    results = []
    for change in dataset["vendor_changes"]:
        if change["changed_field"] not in SENSITIVE_FIELDS:
            continue
        identity = check_api_identity(change["changed_by"], dataset["register"])
        approval = verify_approval(change, dataset["approvals"])
        correlation = correlate(change, dataset["api_logs"])
        decision, reasons, evidence, action = decide(change, identity, approval, correlation)
        results.append({
            "vendor_id": change["vendor_id"],
            "vendor_name": change.get("vendor_name", ""),
            "record_id": change["record_id"],
            "timestamp": change["timestamp"],
            "changed_by": change["changed_by"],
            "source_ip": change.get("source_ip", ""),
            "request_id": change["request_id"],
            "old_masked": mask_account(change.get("old_value")),
            "new_masked": mask_account(change.get("new_value")),
            "identity_status": identity["status"],
            "approval_status": approval["status"],
            "correlated": correlation["matched"],
            "decision": decision,
            "reasons": reasons,
            "evidence": evidence,
            "explanation": explain(change, identity, approval, correlation, decision),
            "recommended_action": action,
            "source_file": dataset["_source_file"],
            "source_sha256": dataset["_sha256"],
            "synthetic": dataset.get("synthetic", False),
        })
    return results


def explain(change, identity, approval, correlation, decision):
    """Plain-language explanation built only from the values in this result."""
    text = (f"An API request using {change['changed_by']} changed the bank details of vendor "
            f"{change['vendor_id']} ({change.get('vendor_name', 'unnamed')}).")
    if correlation["matched"]:
        text += " The API log and the change record match on request ID, key, IP and timestamp."
    if approval["status"] == "missing":
        text += " The change record contains no approval reference."
    elif approval["status"] == "valid":
        text += " A matching, independent approval was found."
    else:
        text += " The approval reference could not be validated."
    if identity["status"] == "unknown":
        text += " The key is not in the integration register."
    elif identity["findings"]:
        text += " The key's permissions or restrictions need review."
    return text + f" Decision: {decision}."
