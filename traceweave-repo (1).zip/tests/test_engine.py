import copy
import json
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from app.engine import load_dataset, analyse, mask_account, DECISION_VERIFIED, DECISION_REVIEW, DECISION_REJECT  # noqa

EVIDENCE = os.path.join(ROOT, "data", "evidence_excerpt.json")
SCEN_A = os.path.join(ROOT, "data", "synthetic", "scenario_A_legitimate.json")
SCEN_C = os.path.join(ROOT, "data", "synthetic", "scenario_C_unauthorised.json")


def write_tmp(obj):
    fd, path = tempfile.mkstemp(suffix=".json")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    return path


def base_data():
    return load_dataset(SCEN_A)


class EvidenceTests(unittest.TestCase):
    def test_e19_is_manual_review_and_correlated(self):
        res = analyse(load_dataset(EVIDENCE))
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0]["decision"], DECISION_REVIEW)
        self.assertTrue(res[0]["correlated"])
        self.assertEqual(res[0]["approval_status"], "missing")
        self.assertIn("Approval reference is blank in the change record", res[0]["reasons"])

    def test_evidence_masks_bank_accounts(self):
        res = analyse(load_dataset(EVIDENCE))[0]
        self.assertEqual(res["old_masked"], "****4417")
        self.assertEqual(res["new_masked"], "****9083")

    def test_evidence_records_hash_and_source(self):
        res = analyse(load_dataset(EVIDENCE))[0]
        self.assertEqual(len(res["source_sha256"]), 64)
        self.assertFalse(res["synthetic"])

    def test_explanation_does_not_claim_fraud(self):
        text = analyse(load_dataset(EVIDENCE))[0]["explanation"].lower()
        self.assertNotIn("fraud", text)
        self.assertNotIn("stolen", text)
        self.assertNotIn("compromis", text)


class ScenarioTests(unittest.TestCase):
    def test_scenario_a_verified(self):
        res = analyse(load_dataset(SCEN_A))[0]
        self.assertEqual(res["decision"], DECISION_VERIFIED)
        self.assertEqual(res["approval_status"], "valid")

    def test_scenario_c_rejected(self):
        res = analyse(load_dataset(SCEN_C))[0]
        self.assertEqual(res["decision"], DECISION_REJECT)
        self.assertEqual(res["identity_status"], "unknown")


class EdgeCaseTests(unittest.TestCase):
    def test_approval_mismatch_rejected(self):
        d = base_data()
        d["approvals"][0]["new_bank_account"] = "****0000"
        self.assertEqual(analyse(d)[0]["decision"], DECISION_REJECT)

    def test_approval_after_change_rejected(self):
        d = base_data()
        d["approvals"][0]["approved_at"] = "2026-10-13T00:00:00+00:00"
        self.assertEqual(analyse(d)[0]["decision"], DECISION_REJECT)

    def test_self_approval_rejected(self):
        d = base_data()
        d["approvals"][0]["approver"] = "key-sync-02"
        self.assertEqual(analyse(d)[0]["decision"], DECISION_REJECT)

    def test_unknown_approval_reference_rejected(self):
        d = base_data()
        d["vendor_changes"][0]["approval_reference"] = "APR-NOPE"
        self.assertEqual(analyse(d)[0]["decision"], DECISION_REJECT)

    def test_missing_expiry_triggers_review_even_with_approval(self):
        d = base_data()
        d["register"][0]["expires"] = None
        res = analyse(d)[0]
        self.assertEqual(res["decision"], DECISION_REVIEW)
        self.assertTrue(any("expiry" in r for r in res["reasons"]))

    def test_no_api_log_triggers_review(self):
        d = base_data()
        d["api_logs"] = []
        res = analyse(d)[0]
        self.assertFalse(res["correlated"])
        self.assertEqual(res["decision"], DECISION_REVIEW)

    def test_non_sensitive_field_is_ignored(self):
        d = base_data()
        d["vendor_changes"][0]["changed_field"] = "contact_phone"
        self.assertEqual(analyse(d), [])

    def test_source_files_unchanged_by_analysis(self):
        with open(EVIDENCE, "rb") as f:
            before = f.read()
        analyse(load_dataset(EVIDENCE))
        with open(EVIDENCE, "rb") as f:
            self.assertEqual(before, f.read())


class ValidationTests(unittest.TestCase):
    def test_missing_list_raises(self):
        path = write_tmp({"register": [], "vendor_changes": [], "api_logs": []})
        with self.assertRaises(ValueError):
            load_dataset(path)
        os.remove(path)

    def test_missing_field_raises(self):
        d = copy.deepcopy(base_data())
        d.pop("_sha256", None); d.pop("_source_file", None)
        del d["vendor_changes"][0]["request_id"]
        path = write_tmp(d)
        with self.assertRaises(ValueError):
            load_dataset(path)
        os.remove(path)

    def test_malformed_json_raises(self):
        fd, path = tempfile.mkstemp(suffix=".json")
        with os.fdopen(fd, "w") as f:
            f.write("{not json")
        with self.assertRaises(json.JSONDecodeError):
            load_dataset(path)
        os.remove(path)

    def test_mask_account(self):
        self.assertEqual(mask_account("****9083"), "****9083")
        self.assertEqual(mask_account("1234567890"), "****7890")
        self.assertEqual(mask_account(None), "-")


if __name__ == "__main__":
    unittest.main(verbosity=2)
